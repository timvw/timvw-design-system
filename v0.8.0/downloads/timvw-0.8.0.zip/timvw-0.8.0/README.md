# timvw 0.8.0

No framework, package installation or build step is required.

Serve this directory with any static HTTP server and open starter.html.
For example: `python3 -m http.server 8080`, then http://localhost:8080/starter.html.
JavaScript ES modules require HTTP; opening directly from disk may be restricted.

For the complete set, load css/timvw.css and css/components.css, and call init() from js/timvw.js.
For one-import tags with native slots, import components/dialog.js or components/card.js; read WEB_COMPONENTS.md.
For selective loading and reusable native HTML templates, read MODULES.md.
Preserve relative paths and third-party notices when copying files.

Documentation and examples: https://timvw.github.io/timvw-design-system/v0.8.0/
Repository: https://github.com/timvw/timvw-design-system

bundle.json lists a SHA-256 checksum for every payload file except itself.
